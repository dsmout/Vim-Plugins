"""Snippet sources that are file based."""
